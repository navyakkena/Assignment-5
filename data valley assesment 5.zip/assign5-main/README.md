# assign5
Write a java program to store Department(id, name) object in database, use PreparedStatement and required steps to complete the given problem statement. Note: use database name: departments and table name: department.
